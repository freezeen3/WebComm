console.log('Client-side code running');

const button = document.getElementById('myButton');
button.addEventListener('click', function() {
  modifyText("four");
  console.log('button was clicked');
});

// Function to change the content of t2
function modifyText() {
  const t2 = document.getElementById("t2");
  if (t2.firstChild.nodeValue == "three") {
    t2.firstChild.nodeValue = "two";
  } else {
    t2.firstChild.nodeValue = "three";
  }
}

// Add event listener to table
const el = document.getElementById("outside");
el.addEventListener("click", modifyText, false);

// <button class="btn btn-success">Install</button>
//
// // Client Side Ajax Script
// <script>
//     $('button').click(function () {
//         $.post('/page', {data: 'blah'}, function (data) {
//         console.log(data);
//       });
//     }, 'json');
// </script>
